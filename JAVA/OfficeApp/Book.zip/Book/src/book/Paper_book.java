package book;

public class Paper_book extends Book_id
{
  
	private double d_charges;
	
	public Paper_book() {
		// TODO Auto-generated constructor stub
	}

	

	public Paper_book(int id, String title, double price, double d_charges) {
		super(id, title, price);
		this.d_charges = d_charges;
	}



	@Override
	public double calCost() {
		// TODO Auto-generated method stub
		return super.price+d_charges;
	}

}
