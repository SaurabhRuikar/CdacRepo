package book;

public class Ebook extends Book_id {
	
	
	private double discount;

	public Ebook() {
		// TODO Auto-generated constructor stub
	}

	public Ebook(int id, String title, double price,Double discount) 
	{
		super(id, title, price);
		this.discount = discount;
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calCost() {
		// TODO Auto-generated method stub
		return (super.price-discount);
	}

}
