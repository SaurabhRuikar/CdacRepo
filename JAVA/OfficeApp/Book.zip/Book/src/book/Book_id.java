package book;

public abstract class Book_id 
{
     private int id;
	 private  String title;
     protected double  price;
	public Book_id() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book_id(int id, String title, double price) {
		super();
		this.id = id;
		this.title = title;
		this.price = price;
	}
     
	public abstract double calCost();

     
}
